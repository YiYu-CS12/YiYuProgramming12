public enum Suit {
    HEARTS, DIAMONDS, CLUBS, SPADES
}