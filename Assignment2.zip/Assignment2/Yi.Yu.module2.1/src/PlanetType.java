public enum PlanetType {
    TypeA, TypeB, TypeC, TypeD
}
